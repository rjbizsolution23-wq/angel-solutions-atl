import { HeroSection } from '@/components/sections/hero-section'
import { StatsSection } from '@/components/sections/stats-section'
import { ServicesOverview } from '@/components/sections/services-overview'
import { FeaturesSection } from '@/components/sections/features-section'
import { TestimonialsSection } from '@/components/sections/testimonials-section'
import { CTASection } from '@/components/sections/cta-section'
import { AboutPreview } from '@/components/sections/about-preview'

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <StatsSection />
      <AboutPreview />
      <ServicesOverview />
      <FeaturesSection />
      <TestimonialsSection />
      <CTASection />
    </>
  )
}
