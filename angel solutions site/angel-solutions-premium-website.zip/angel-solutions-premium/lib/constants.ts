export const SITE_CONFIG = {
  name: 'Angel Solutions ATL',
  description: 'Elite Business, Tax & Financial Solutions',
  url: 'https://www.angelsolutionsatl.com',
  email: 'info@AngelSolutionsATL.com',
  phone: '+1 (404) XXX-XXXX', // Add actual phone
  address: {
    street: 'Atlanta, GA',
    city: 'Atlanta',
    state: 'GA',
    country: 'United States',
  },
  social: {
    facebook: '#',
    twitter: '#',
    instagram: '#',
    linkedin: '#',
  },
} as const

export const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About Us' },
  { href: '/business-solutions', label: 'Business Solutions' },
  { href: '/tax-solutions', label: 'Tax Solutions' },
  { href: '/financial-solutions', label: 'Financial Solutions' },
  { href: '/contact', label: 'Contact' },
] as const

export const BUSINESS_PACKAGES = [
  {
    id: 'option-1',
    name: 'Starter Package',
    price: 450,
    popular: false,
    features: [
      'LLC registration & Articles of Incorporation',
      'Dun & Bradstreet registration',
      'Business domain and email',
      'EIN number (tax purposes)',
      'Business directory registration',
      'SEO optimization',
      'Professionally designed business logo',
      'Virtual office with corporate mailing address',
    ],
    virtualOfficeFee: 10,
    virtualOfficeInterval: 'month',
  },
  {
    id: 'option-2',
    name: 'Professional Package',
    price: 550,
    popular: true,
    features: [
      'All Starter Package features',
      'Enhanced virtual office services',
      'Local or Toll-Free Business Phone & Fax',
      'Call forwarding to your choice',
      'Voicemail to email conversion',
      'Digital scans of all incoming mail',
      'Automatic mail forwarding option',
    ],
    virtualOfficeFee: 39.99,
    virtualOfficeInterval: 'month',
  },
  {
    id: 'option-3',
    name: 'Elite Enterprise Package',
    price: 650,
    popular: false,
    features: [
      'All Professional Package features',
      'Live receptionist (Mon-Fri)',
      'Business credit building with monthly reporting',
      'Reports to all 3 business credit bureaus',
      'Premium phone features available',
      'Text from your business number',
      'Call recording capability',
      'Dial out from business number',
      'Additional toll-free number option',
    ],
    virtualOfficeFee: 100,
    virtualOfficeInterval: 'month',
  },
] as const

export const TAX_SERVICES = [
  {
    id: 'tax-prep',
    title: 'Tax Preparation',
    description: 'Professional tax preparation for individuals and businesses',
    icon: 'FileText',
  },
  {
    id: 'irs-compliance',
    title: 'IRS Compliance Audits',
    description: 'Comprehensive IRS compliance reviews and audit support',
    icon: 'Shield',
  },
  {
    id: 'tax-negotiation',
    title: 'Tax Debt Negotiation',
    description: 'Expert negotiation to reduce your tax liability',
    icon: 'Handshake',
  },
  {
    id: 'tax-resolution',
    title: 'Tax Debt Resolution',
    description: 'Complete resolution of outstanding tax debts',
    icon: 'CheckCircle',
  },
  {
    id: 'transcripts',
    title: 'Tax Transcripts',
    description: 'Quick access to your official IRS tax transcripts',
    icon: 'FileSearch',
  },
  {
    id: 'investigations',
    title: 'IRS Investigations',
    description: 'Professional representation for IRS investigations',
    icon: 'Search',
  },
  {
    id: 'lien-levy',
    title: 'Lien/Levy Relief',
    description: 'Immediate relief from IRS liens and levies',
    icon: 'AlertCircle',
  },
] as const

export const FINANCIAL_SOLUTIONS_FEATURES = [
  {
    title: 'Credit Score Optimization',
    description: 'Build favorable consumer reports with increased scores',
  },
  {
    title: 'Budgeting Techniques',
    description: 'Learn to manage your finances effectively',
  },
  {
    title: 'Debt Elimination',
    description: 'Strategic plans to eliminate debt responsibly',
  },
  {
    title: 'Credit Education',
    description: 'Understand how to leverage good credit',
  },
  {
    title: 'Consumer Rights',
    description: 'Enforce your consumer rights and protections',
  },
  {
    title: 'Strategic Planning',
    description: 'Make financial decisions that aid personal and business gains',
  },
] as const

export const TESTIMONIALS = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'Small Business Owner',
    content: 'Angel Solutions ATL transformed my business. Their professional package gave me everything I needed to establish credibility and start strong.',
    rating: 5,
    image: '/testimonials/client-1.jpg',
  },
  {
    id: 2,
    name: 'Michael Rodriguez',
    role: 'Entrepreneur',
    content: 'The tax resolution services saved my business. Professional, efficient, and they delivered exactly what they promised.',
    rating: 5,
    image: '/testimonials/client-2.jpg',
  },
  {
    id: 3,
    name: 'Emily Davis',
    role: 'Real Estate Investor',
    content: 'Their financial solutions helped me optimize my credit and secure funding. Couldn\'t have done it without their expertise.',
    rating: 5,
    image: '/testimonials/client-3.jpg',
  },
] as const

export const STATS = [
  { label: 'Businesses Launched', value: '500+' },
  { label: 'Client Satisfaction', value: '98%' },
  { label: 'Tax Cases Resolved', value: '$2M+' },
  { label: 'Years of Excellence', value: '5+' },
] as const
